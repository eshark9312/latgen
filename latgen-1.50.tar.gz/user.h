#ifndef USER_H
#define USER_H

#include "lattice.h"

class USER : public lattice {
public:
  
  USER();
  ~USER();
};
#endif
